import pandas as pd
import os
import sys
import traceback

# === CONFIGURATION ===
INPUT_FILE = "nessus_scan.xlsx"             # Original Nessus export
MID_FILE = "processed_nessus_scan.xlsx"     # After Description-level processing
FINAL_FILE = "processed_by_host.xlsx"       # After Host-level filtering

RISK_PRIORITY = ['Info', 'Low', 'Medium', 'High', 'Critical']

def risk_rank(risk):
    """Return numeric rank for risk level (higher = more severe)."""
    try:
        return RISK_PRIORITY.index(str(risk).strip().title())
    except ValueError:
        return -1

# -------------------------------------------------------------------
# STEP 1: GROUP BY DESCRIPTION
# -------------------------------------------------------------------
def process_by_description(df):
    print("⚙️  Step 1: Grouping by Description...")
    grouped = (
        df.groupby('Description', dropna=False)
        .agg({
            'Risk': lambda x: max(x, key=lambda r: risk_rank(r)),
            'Host': lambda x: '\n'.join(sorted(set(str(v).strip() for v in x if pd.notna(v)))),
            'Name': 'first',
            'Synopsis': 'first',
            'Solution': 'first'
        })
        .reset_index()
    )
    grouped = grouped[['Name', 'Risk', 'Host', 'Description', 'Synopsis', 'Solution']]
    print(f"✅ Grouped by Description: {len(df)} → {len(grouped)} rows.")
    return grouped

# -------------------------------------------------------------------
# STEP 2: GROUP BY HOST
# -------------------------------------------------------------------
def process_by_host(df):
    print("⚙️  Step 2: Grouping by Host (unique host blocks, keep highest risk)...")
    df['Risk'] = df['Risk'].astype(str).str.strip().str.title()
    df['risk_rank'] = df['Risk'].apply(risk_rank)
    grouped = (
        df.sort_values(by='risk_rank', ascending=False)
          .groupby('Host', dropna=False, as_index=False)
          .first()
    )
    grouped = grouped[['Name', 'Risk', 'Host', 'Description', 'Synopsis', 'Solution']]
    print(f"✅ Grouped by Host: {len(df)} → {len(grouped)} rows.")
    return grouped

# -------------------------------------------------------------------
# MAIN EXECUTION
# -------------------------------------------------------------------
def main():
    print("🔍 Nessus Excel Processor (Combined Mode)")
    print("=" * 70)

    # --- Step 0: Validate input file ---
    if not os.path.exists(INPUT_FILE):
        print(f"❌ ERROR: Input file '{INPUT_FILE}' not found in directory: {os.getcwd()}")
        sys.exit(1)
    print(f"📂 Found input file: {INPUT_FILE}")

    try:
        # --- Read the input file ---
        print("📖 Reading Nessus Excel data...")
        df = pd.read_excel(INPUT_FILE)
        print(f"✅ Loaded {len(df)} rows and {len(df.columns)} columns.")

        # --- Validate required columns ---
        required_cols = ['Risk', 'Host', 'Name', 'Synopsis', 'Description', 'Solution']
        missing = [c for c in required_cols if c not in df.columns]
        if missing:
            print(f"❌ ERROR: Missing required columns: {missing}")
            sys.exit(1)
        print("✅ All required columns are present.")

        # --- Step 1: Process by Description ---
        df_desc = process_by_description(df)
        df_desc.to_excel(MID_FILE, index=False)
        print(f"💾 Intermediate file saved as: {MID_FILE}")

        # --- Step 2: Process by Host ---
        df_host = process_by_host(df_desc)
        df_host.to_excel(FINAL_FILE, index=False)
        print(f"💾 Final file saved as: {FINAL_FILE}")

        # --- Step 3: Delete intermediate file ---
        if os.path.exists(MID_FILE):
            os.remove(MID_FILE)
            print(f"🗑️  Intermediate file '{MID_FILE}' deleted.")

    except Exception:
        print("❌ ERROR: An unexpected error occurred.")
        print("-" * 70)
        traceback.print_exc()
        print("-" * 70)
        sys.exit(1)

    print("=" * 70)
    print("🎉 Processing completed successfully.")
    print(f"📘 Final output file: {FINAL_FILE}")

if __name__ == "__main__":
    main()