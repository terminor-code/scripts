import pandas as pd
import os

# === CONFIGURATION ===
INPUT_FILE = "nessus_scan.xlsx"  # <-- Change this if your Nessus Excel filename is different
OUTPUT_FILE = "filtered_nessus_scan.xlsx"

# Define the risk ranking (edit if Nessus uses other terms)
RISK_PRIORITY = ['Info', 'Low', 'Medium', 'High', 'Critical']

def risk_rank(risk):
    """Return rank based on priority list."""
    try:
        return RISK_PRIORITY.index(str(risk).strip().title())
    except ValueError:
        return -1

def main():
    # Check if the file exists
    if not os.path.exists(INPUT_FILE):
        print(f"❌ Input file '{INPUT_FILE}' not found in the current directory.")
        return

    print(f"📂 Processing Nessus Excel file: {INPUT_FILE}")

    # Read the Excel file
    df = pd.read_excel(INPUT_FILE)

    # Verify required columns
    required_cols = ['Risk', 'Host', 'Name', 'Synopsis', 'Description', 'Solution']
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        print(f"❌ Missing columns in Excel file: {missing}")
        return

    # Group by Description
    grouped = (
        df.groupby('Description', dropna=False)
        .agg({
            'Risk': lambda x: max(x, key=lambda r: risk_rank(r)),
            'Host': lambda x: '\n'.join(sorted(set(str(v).strip() for v in x if pd.notna(v)))),
            'Name': 'first',
            'Synopsis': 'first',
            'Solution': 'first'
        })
        .reset_index()
    )

    # Reorder columns
    final_cols = ['Name', 'Risk', 'Host', 'Description', 'Synopsis', 'Solution']
    grouped = grouped[final_cols]

    # Write to Excel
    grouped.to_excel(OUTPUT_FILE, index=False)
    print(f"✅ Done! Output saved as: {OUTPUT_FILE}")
    print("ℹ️ Hosts are newline-separated within each cell (enable 'Wrap Text' in Excel).")

if __name__ == "__main__":
    main()