import pandas as pd
import os
import sys
import traceback

# === CONFIGURATION ===
INPUT_FILE = "nessus_scan.xlsx"
OUTPUT_FILE = "processed_nessus.xlsx"
REMOVE_PHRASE = "Note that Nessus has not tested for these issues"
RISK_PRIORITY = ['Info', 'Low', 'Medium', 'High', 'Critical']  # Risk hierarchy
COLUMN_ORDER = ['Name', 'Risk', 'Host', 'Description', 'Synopsis', 'Solution']

def risk_rank(risk):
    """Return index for risk priority (higher is worse)."""
    try:
        return RISK_PRIORITY.index(str(risk).title())
    except ValueError:
        return -1

def clean_description(text):
    """Remove lines containing the REMOVE_PHRASE."""
    if pd.isna(text):
        return text
    lines = str(text).splitlines()
    cleaned_lines = [line for line in lines if REMOVE_PHRASE not in line]
    return "\n".join(cleaned_lines)

def merge_hosts(hosts):
    """Merge multiple hosts into newline-separated string, removing duplicates."""
    hosts = [str(h).strip() for h in hosts if pd.notna(h)]
    return "\n".join(sorted(set(hosts)))

def main():
    print("🔍 Processing Nessus Excel file...")
    print("=" * 60)

    if not os.path.exists(INPUT_FILE):
        print(f"❌ ERROR: Input file '{INPUT_FILE}' not found in directory: {os.getcwd()}")
        sys.exit(1)

    try:
        df = pd.read_excel(INPUT_FILE)
        print(f"📖 Loaded {len(df)} rows and {len(df.columns)} columns.")

        # Ensure required columns exist
        required_cols = ['Risk', 'Host', 'Name', 'Description', 'Synopsis', 'Solution']
        for col in required_cols:
            if col not in df.columns:
                print(f"❌ ERROR: Required column '{col}' not found in Excel file.")
                sys.exit(1)

        # Clean Description column
        df['Description'] = df['Description'].apply(clean_description)
        print("✅ Cleaned Description column (removed specific Nessus note).")

        # Normalize Risk
        df['Risk'] = df['Risk'].astype(str).str.strip().str.title()

        # --- First-level grouping by Description ---
        grouped_desc = df.groupby('Description', as_index=False).agg({
            'Host': merge_hosts,
            'Risk': lambda x: max(x, key=risk_rank),
            'Name': 'first',
            'Synopsis': 'first',
            'Solution': 'first'
        })
        print("✅ Grouped by Description (merged hosts, kept highest Risk).")

        # --- Second-level grouping by Host ---
        grouped_host = grouped_desc.groupby('Host', as_index=False).agg({
            'Risk': lambda x: max(x, key=risk_rank),
            'Name': 'first',
            'Description': 'first',
            'Synopsis': 'first',
            'Solution': 'first'
        })
        print("✅ Grouped by Host (kept highest Risk).")

        # Reorder columns
        grouped_host = grouped_host[COLUMN_ORDER]

        # --- Sort by Risk hierarchy ---
        grouped_host['Risk_rank'] = grouped_host['Risk'].apply(risk_rank)
        grouped_host = grouped_host.sort_values(by='Risk_rank', ascending=False).drop(columns='Risk_rank')
        print("✅ Sorted rows by Risk hierarchy (Critical > High > Medium > Low > Info).")

        # --- Add Serial Number column ---
        grouped_host.insert(0, 'S.No', range(1, len(grouped_host) + 1))
        print("✅ Added Serial Number column at the front.")

        # Save final output
        grouped_host.to_excel(OUTPUT_FILE, index=False)
        print(f"💾 Processed file saved as: {OUTPUT_FILE}")

    except Exception:
        print("❌ ERROR: An unexpected error occurred.")
        print("-" * 60)
        traceback.print_exc()
        print("-" * 60)
        sys.exit(1)

    print("=" * 60)
    print("🎉 Nessus processing completed successfully.")

if __name__ == "__main__":
    main()