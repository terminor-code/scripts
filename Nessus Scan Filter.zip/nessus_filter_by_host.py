import pandas as pd
import os
import sys
import traceback

# === CONFIGURATION ===
INPUT_FILE = "filtered_nessus_scan.xlsx"   # Output from the first script
OUTPUT_FILE = "filtered_by_host.xlsx"      # Final output after host-level filtering
RISK_PRIORITY = ['Info', 'Low', 'Medium', 'High', 'Critical']

def risk_rank(risk):
    """Return numeric rank for risk level (higher = more severe)."""
    try:
        return RISK_PRIORITY.index(str(risk).strip().title())
    except ValueError:
        return -1

def main():
    print("🔍 Second-Level Filter: Group by Host (Keep Highest Risk per Unique Host)")
    print("=" * 60)

    # --- Step 1: Check input file ---
    if not os.path.exists(INPUT_FILE):
        print(f"❌ ERROR: Input file '{INPUT_FILE}' not found in directory: {os.getcwd()}")
        sys.exit(1)
    print(f"📂 Found input file: {INPUT_FILE}")

    try:
        # --- Step 2: Read data ---
        print("📖 Reading Excel data...")
        df = pd.read_excel(INPUT_FILE)
        print(f"✅ Loaded {len(df)} rows and {len(df.columns)} columns.")

        # --- Step 3: Validate columns ---
        required_cols = ['Name', 'Risk', 'Host', 'Description', 'Synopsis', 'Solution']
        missing = [c for c in required_cols if c not in df.columns]
        if missing:
            print(f"❌ ERROR: Missing required columns: {missing}")
            sys.exit(1)
        print("✅ All required columns are present.")

        # --- Step 4: Normalize risk values ---
        df['Risk'] = df['Risk'].astype(str).str.strip().str.title()
        df['risk_rank'] = df['Risk'].apply(risk_rank)

        # --- Step 5: Group by Host (treat each unique Host cell as one group) ---
        print("⚙️  Grouping by unique Host values and keeping highest Risk per Host...")
        grouped = (
            df.sort_values(by='risk_rank', ascending=False)
              .groupby('Host', dropna=False, as_index=False)
              .first()
        )
        print(f"✅ Grouped data: reduced from {len(df)} rows to {len(grouped)} unique Host entries.")

        # --- Step 6: Reorder columns ---
        final_cols = ['Name', 'Risk', 'Host', 'Description', 'Synopsis', 'Solution']
        grouped = grouped[final_cols]

        # --- Step 7: Write output ---
        print(f"💾 Writing results to '{OUTPUT_FILE}'...")
        grouped.to_excel(OUTPUT_FILE, index=False)
        print(f"✅ Output saved successfully as: {OUTPUT_FILE}")

    except Exception:
        print("❌ ERROR: An unexpected error occurred.")
        print("-" * 60)
        traceback.print_exc()
        print("-" * 60)
        sys.exit(1)

    print("=" * 60)
    print("🎉 Host-level grouping and filtering completed successfully.")

if __name__ == "__main__":
    main()