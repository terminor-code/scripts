import pandas as pd
import re
import os
import sys

# === CONFIGURATION ===
INPUT_FILE = "Full Trust Summary_V1.0.xlsx"
OUTPUT_FILE = "Full Trust Summary_V1.1.xlsx"
DESCRIPTION_COLUMN = "Description"

# Desired column order
COLUMN_ORDER = ["S.No", "Name", "CVE", "Risk", "Host", "Description", "Recommendations"]

# === CVE REGEX ===
CVE_PATTERN = re.compile(r"CVE-\d{4}-\d{4,7}", re.IGNORECASE)


def extract_cves(text):
    """Extract unique CVE IDs from text and return them as newline-separated string."""
    if isinstance(text, str) and text.strip():
        text = text.replace("\r", "\n")
        cves = CVE_PATTERN.findall(text)
        if cves:
            unique_cves = sorted(set(cve.upper() for cve in cves))
            return "\n".join(unique_cves)  # Each CVE on its own line
    return ""


def main():
    print("🔍 Starting CVE extraction from Nessus Excel report...")

    if not os.path.exists(INPUT_FILE):
        print(f"❌ ERROR: File '{INPUT_FILE}' not found.")
        sys.exit(1)

    try:
        df = pd.read_excel(INPUT_FILE)
        print(f"✅ File '{INPUT_FILE}' loaded successfully with {len(df)} rows.")
    except Exception as e:
        print(f"❌ ERROR: Could not read Excel file. Details: {e}")
        sys.exit(1)

    # Check for required columns
    required_cols = ["S.No", "Name", "Risk", "Host", "Description", "Recommendations"]
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        print(f"❌ ERROR: Missing required columns: {missing_cols}")
        sys.exit(1)

    # Stop at first completely empty row
    empty_row_index = df[df.isnull().all(axis=1)].index
    if not empty_row_index.empty:
        df = df.loc[:empty_row_index[0] - 1]
        print(f"ℹ️ Stopped at first empty row (index {empty_row_index[0]}).")
    else:
        print("ℹ️ No empty rows detected — processing entire sheet.")

    # Extract CVEs
    print("🔎 Extracting CVEs from Description column...")
    try:
        df["CVE"] = df[DESCRIPTION_COLUMN].apply(extract_cves)
    except Exception as e:
        print(f"❌ ERROR: Problem during CVE extraction: {e}")
        sys.exit(1)

    # Reorder columns
    existing_cols = list(df.columns)
    final_cols = [col for col in COLUMN_ORDER if col in existing_cols]
    df = df[final_cols]
    print("🔄 Columns reordered successfully.")

    # Save output
    try:
        df.to_excel(OUTPUT_FILE, index=False)
        print(f"💾 Results saved to '{OUTPUT_FILE}' successfully.")
    except Exception as e:
        print(f"❌ ERROR: Failed to save output file. Details: {e}")
        sys.exit(1)

    print("🎉 CVE extraction completed successfully!")


if __name__ == "__main__":
    main()
