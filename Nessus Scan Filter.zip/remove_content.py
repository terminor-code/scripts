import pandas as pd
import os
import sys
import traceback

# === CONFIGURATION ===
INPUT_FILE = "Trust_final_v1.0.xlsx"
OUTPUT_FILE = "cleaned_Trust_final_v1.0.xlsx"
REMOVE_PHRASE = "Note that Nessus has not tested for these issues"

def clean_description(text):
    """
    Remove any line(s) that contain the REMOVE_PHRASE.
    Works even if the line wraps across multiple lines in Excel.
    """
    if pd.isna(text):
        return text
    
    lines = str(text).splitlines()
    cleaned_lines = []
    skip_next = False
    for i, line in enumerate(lines):
        if REMOVE_PHRASE in line:
            # Skip this line
            skip_next = True
            continue
        if skip_next:
            # Also skip the wrapped line (if it starts with lowercase or is continuation)
            skip_next = False
            continue
        cleaned_lines.append(line)
    
    return "\n".join(cleaned_lines)

def main():
    print("🔍 Cleaning Description column...")
    print("=" * 60)

    if not os.path.exists(INPUT_FILE):
        print(f"❌ ERROR: Input file '{INPUT_FILE}' not found in directory: {os.getcwd()}")
        sys.exit(1)

    try:
        df = pd.read_excel(INPUT_FILE)
        print(f"📖 Loaded {len(df)} rows and {len(df.columns)} columns.")

        if 'Description' not in df.columns:
            print("❌ ERROR: 'Description' column not found in the Excel file.")
            sys.exit(1)

        df['Description'] = df['Description'].apply(clean_description)
        print("✅ Specific lines removed from Description where applicable.")

        df.to_excel(OUTPUT_FILE, index=False)
        print(f"💾 Cleaned file saved as: {OUTPUT_FILE}")

    except Exception:
        print("❌ ERROR: An unexpected error occurred.")
        print("-" * 60)
        traceback.print_exc()
        print("-" * 60)
        sys.exit(1)

    print("=" * 60)
    print("🎉 Description cleaning completed successfully.")

if __name__ == "__main__":
    main()