import pandas as pd
import re
import sys
import os

# === CONFIGURATION ===
INPUT_FILE = "test2.xlsx"
OUTPUT_FILE = "test2_filtered.xlsx"
DESCRIPTION_COLUMN = "Description"  # Adjust if your sheet uses a different header

# Desired column order
COLUMN_ORDER = ["S.No", "Name", "CVE", "Risk", "Host", "Description", "Synopsis", "Solution"]

# === CVE REGEX ===
CVE_PATTERN = re.compile(r"CVE-\d{4}-\d{4,7}", re.IGNORECASE)


def extract_cves(text):
    """Extract unique CVE IDs from text and return them as newline-separated string."""
    if isinstance(text, str) and text.strip():
        text = text.replace("\r", "\n")
        cves = CVE_PATTERN.findall(text)
        if cves:
            unique_cves = sorted(set(cve.upper() for cve in cves))
            return "\n".join(unique_cves)  # Each CVE on its own line
    return ""


def main():
    print("🔍 Starting CVE extraction from Nessus Excel report...")

    # === Step 1: Check file existence ===
    if not os.path.exists(INPUT_FILE):
        print(f"❌ ERROR: File '{INPUT_FILE}' not found. Please check the path and filename.")
        sys.exit(1)

    try:
        df = pd.read_excel(INPUT_FILE)
        print(f"✅ File '{INPUT_FILE}' loaded successfully.")
    except Exception as e:
        print(f"❌ ERROR: Could not read Excel file. Details: {e}")
        sys.exit(1)

    # === Step 2: Check for Description column ===
    if DESCRIPTION_COLUMN not in df.columns:
        print(f"❌ ERROR: Column '{DESCRIPTION_COLUMN}' not found.")
        print(f"👉 Available columns: {list(df.columns)}")
        sys.exit(1)
    else:
        print(f"✅ Found column '{DESCRIPTION_COLUMN}'.")

    # === Step 3: Stop processing at first completely empty row ===
    empty_row_index = df[df.isnull().all(axis=1)].index
    if not empty_row_index.empty:
        df = df.loc[:empty_row_index[0] - 1]
        print(f"ℹ️ Detected empty row at index {empty_row_index[0]}. Stopping there.")
    else:
        print("ℹ️ No empty rows found — processing entire sheet.")

    # === Step 4: Extract CVEs ===
    print("🔎 Extracting CVEs from Description column...")
    try:
        df["CVE"] = df[DESCRIPTION_COLUMN].apply(extract_cves)
    except Exception as e:
        print(f"❌ ERROR: Problem during CVE extraction: {e}")
        sys.exit(1)

    # === Step 5: Keep only rows with CVEs ===
    df = df[df["CVE"].str.strip() != ""]
    print(f"✅ Found {len(df)} rows containing CVEs.")

    # === Step 6: Reorder columns ===
    existing_cols = list(df.columns)
    ordered_cols = [col for col in COLUMN_ORDER if col in existing_cols]
    remaining_cols = [col for col in existing_cols if col not in ordered_cols]
    final_cols = ordered_cols + remaining_cols  # keep extras at the end
    df = df[final_cols]
    print("🔄 Columns reordered successfully.")

    # === Step 7: Save output ===
    try:
        df.to_excel(OUTPUT_FILE, index=False)
        print(f"💾 Results saved to '{OUTPUT_FILE}' successfully.")
    except Exception as e:
        print(f"❌ ERROR: Failed to save output file. Details: {e}")
        sys.exit(1)

    print("🎉 CVE extraction and column formatting completed successfully!")


if __name__ == "__main__":
    main()