import pandas as pd
import os
import sys
import traceback

# === CONFIGURATION ===
INPUT_FILE = "sorted_cleaned_DMZ_final_v1.1.xlsx"
OUTPUT_FILE = "sorted_cleaned_DMZ_final_v1.2.xlsx"
REMOVE_PREFIX = "Note that Nessus has not tested"  # Detect lines starting with this

def clean_description(text):
    """Remove the last lines starting with REMOVE_PREFIX (handles multi-line wrapping)."""
    if pd.isna(text):
        return text
    lines = str(text).splitlines()
    
    # Find the index where the last line starting with REMOVE_PREFIX occurs
    remove_start = None
    for i, line in enumerate(lines):
        if line.strip().startswith(REMOVE_PREFIX):
            remove_start = i
            break
    
    if remove_start is not None:
        # Remove from that line to the end
        lines = lines[:remove_start]
    
    return "\n".join(lines)

def main():
    print("🔍 Cleaning Description column from Nessus note...")
    print("=" * 60)

    if not os.path.exists(INPUT_FILE):
        print(f"❌ ERROR: Input file '{INPUT_FILE}' not found in directory: {os.getcwd()}")
        sys.exit(1)

    try:
        df = pd.read_excel(INPUT_FILE)
        print(f"📖 Loaded {len(df)} rows and {len(df.columns)} columns.")

        if 'Description' not in df.columns:
            print("❌ ERROR: 'Description' column not found.")
            sys.exit(1)

        # Clean Description
        df['Description'] = df['Description'].apply(clean_description)
        print("✅ Removed Nessus notes from Description column.")

        # Save cleaned file
        df.to_excel(OUTPUT_FILE, index=False)
        print(f"💾 Cleaned file saved as: {OUTPUT_FILE}")

    except Exception:
        print("❌ ERROR: Unexpected error occurred.")
        print("-" * 60)
        traceback.print_exc()
        print("-" * 60)
        sys.exit(1)

    print("=" * 60)
    print("🎉 Cleaning completed successfully.")

if __name__ == "__main__":
    main()