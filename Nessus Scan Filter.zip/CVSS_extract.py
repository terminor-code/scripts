import pandas as pd
import os
import sys

# === CONFIGURATION ===
FILTERED_FILE = "filtered.xlsx"   # Your filtered Excel
RAW_FILE = "raw_data.xlsx"        # Your raw Excel
OUTPUT_FILE = "filtered_with_cvss.xlsx"

# Columns
NAME_COLUMN = "Name"
RISK_COLUMN = "Risk"
CVSS_COLUMN = "CVSS 3.0 Base Score"

def main():
    # Check if files exist
    for file in [FILTERED_FILE, RAW_FILE]:
        if not os.path.exists(file):
            print(f"❌ ERROR: File '{file}' not found.")
            sys.exit(1)

    # Load Excel sheets
    try:
        filtered_df = pd.read_excel(FILTERED_FILE)
        raw_df = pd.read_excel(RAW_FILE)
        print(f"✅ Loaded filtered ({len(filtered_df)} rows) and raw ({len(raw_df)} rows) data successfully.")
    except Exception as e:
        print(f"❌ ERROR: Could not read Excel files. Details: {e}")
        sys.exit(1)

    # Check required columns
    for col in [NAME_COLUMN, RISK_COLUMN, CVSS_COLUMN]:
        if col not in raw_df.columns:
            print(f"❌ ERROR: Raw data missing required column '{col}'")
            sys.exit(1)
    for col in [NAME_COLUMN, RISK_COLUMN]:
        if col not in filtered_df.columns:
            print(f"❌ ERROR: Filtered data missing required column '{col}'")
            sys.exit(1)

    # Create a multi-key mapping from (Name, Risk) → CVSS score
    raw_df["_key"] = raw_df[NAME_COLUMN].astype(str).str.strip() + "||" + raw_df[RISK_COLUMN].astype(str).str.strip()
    name_risk_to_cvss = raw_df.set_index("_key")[CVSS_COLUMN].to_dict()

    # Create the same key in filtered sheet
    filtered_df["_key"] = filtered_df[NAME_COLUMN].astype(str).str.strip() + "||" + filtered_df[RISK_COLUMN].astype(str).str.strip()

    # Map CVSS scores
    filtered_df[CVSS_COLUMN] = filtered_df["_key"].map(name_risk_to_cvss)

    # Count how many rows got a score
    scored_rows = filtered_df[CVSS_COLUMN].notna().sum()
    total_rows = len(filtered_df)
    print(f"ℹ️ CVSS scores added for {scored_rows} out of {total_rows} rows.")
    print(f"ℹ️ {total_rows - scored_rows} rows have no score and were skipped.")

    # Remove temporary key column
    filtered_df.drop(columns="_key", inplace=True)

    # Save the updated filtered sheet
    try:
        filtered_df.to_excel(OUTPUT_FILE, index=False)
        print(f"💾 Updated filtered file saved as '{OUTPUT_FILE}'")
    except Exception as e:
        print(f"❌ ERROR: Could not save output file. Details: {e}")
        sys.exit(1)

    print("🎉 CVSS scores successfully added based on Name + Risk!")

if __name__ == "__main__":
    main()