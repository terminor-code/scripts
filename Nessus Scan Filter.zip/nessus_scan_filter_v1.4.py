import pandas as pd
import re
import os
import sys
import traceback

# === CONFIGURATION ===
INPUT_FILE = "test2.xlsx"
OUTPUT_FILE = "test2_filtered.xlsx"
REMOVE_PREFIX = "Note that Nessus has not tested"
RISK_PRIORITY = ['Info', 'Low', 'Medium', 'High', 'Critical']
COLUMN_ORDER = ['S.No', 'Name', 'CVE', 'Risk', 'Host', 'Description', 'Synopsis', 'Solution']

# === CVE REGEX ===
CVE_PATTERN = re.compile(r"CVE-\d{4}-\d{4,7}", re.IGNORECASE)

# === HELPER FUNCTIONS ===
def risk_rank(risk):
    """Return index for risk priority (higher = worse)."""
    try:
        return RISK_PRIORITY.index(str(risk).title())
    except ValueError:
        return -1

def clean_description(text):
    """Remove trailing Nessus note lines (handles multi-line)."""
    if pd.isna(text):
        return text
    lines = str(text).splitlines()
    remove_start = None
    for i, line in enumerate(lines):
        if line.strip().startswith(REMOVE_PREFIX):
            remove_start = i
            break
    if remove_start is not None:
        lines = lines[:remove_start]
    return "\n".join(lines)

def merge_hosts(hosts):
    """Merge multiple hosts into newline-separated string, removing duplicates."""
    hosts = [str(h).strip() for h in hosts if pd.notna(h)]
    return "\n".join(sorted(set(hosts)))

def extract_cves(text):
    """Extract unique CVE IDs and return them as newline-separated string."""
    if isinstance(text, str) and text.strip():
        text = text.replace("\r", "\n")
        cves = CVE_PATTERN.findall(text)
        if cves:
            unique_cves = sorted(set(cve.upper() for cve in cves))
            return "\n".join(unique_cves)
    return ""

# === MAIN SCRIPT ===
def main():
    print("🔍 Starting Nessus processing with CVE extraction...")
    print("=" * 70)

    if not os.path.exists(INPUT_FILE):
        print(f"❌ ERROR: Input file '{INPUT_FILE}' not found in directory: {os.getcwd()}")
        sys.exit(1)

    try:
        df = pd.read_excel(INPUT_FILE)
        print(f"📖 Loaded {len(df)} rows and {len(df.columns)} columns.")

        # Ensure required columns exist
        required_cols = ['Risk', 'Host', 'Name', 'Description', 'Synopsis', 'Solution']
        for col in required_cols:
            if col not in df.columns:
                print(f"❌ ERROR: Required column '{col}' not found in Excel file.")
                sys.exit(1)

        # === Stop at first empty row (if table ends early) ===
        empty_row_index = df[df.isnull().all(axis=1)].index
        if not empty_row_index.empty:
            df = df.loc[:empty_row_index[0] - 1]
            print(f"ℹ️ Detected empty row at index {empty_row_index[0]}. Stopping there.")
        else:
            print("ℹ️ No empty rows found — processing full sheet.")

        # === Clean Description column ===
        df['Description'] = df['Description'].apply(clean_description)
        print("✅ Cleaned Description column (removed multi-line Nessus notes).")

        # === Normalize Risk ===
        df['Risk'] = df['Risk'].astype(str).str.strip().str.title()

        # === Extract CVEs ===
        df['CVE'] = df['Description'].apply(extract_cves)
        print("✅ Extracted CVEs (each on a new line per cell).")

        # === Group by Description (merge hosts, highest risk) ===
        grouped_desc = df.groupby('Description', as_index=False).agg({
            'Host': merge_hosts,
            'Risk': lambda x: max(x, key=risk_rank),
            'Name': 'first',
            'CVE': lambda x: "\n".join(sorted(set("\n".join(x).splitlines()))),
            'Synopsis': 'first',
            'Solution': 'first'
        })
        print("✅ Grouped by Description (merged hosts, combined CVEs, kept highest risk).")

        # === Group by Host (keep highest risk) ===
        grouped_host = grouped_desc.groupby('Host', as_index=False).agg({
            'Risk': lambda x: max(x, key=risk_rank),
            'Name': 'first',
            'CVE': 'first',
            'Description': 'first',
            'Synopsis': 'first',
            'Solution': 'first'
        })
        print("✅ Grouped by Host (kept highest risk per host).")

        # === Sort by risk priority ===
        grouped_host['Risk_rank'] = grouped_host['Risk'].apply(risk_rank)
        grouped_host = grouped_host.sort_values(by='Risk_rank', ascending=False).drop(columns='Risk_rank')
        print("✅ Sorted rows by Risk hierarchy (Critical > High > Medium > Low > Info).")

        # === Add serial numbers ===
        grouped_host.insert(0, 'S.No', range(1, len(grouped_host) + 1))
        print("✅ Added Serial Number column.")

        # === Reorder columns ===
        existing_cols = list(grouped_host.columns)
        ordered_cols = [col for col in COLUMN_ORDER if col in existing_cols]
        remaining_cols = [col for col in existing_cols if col not in ordered_cols]
        grouped_host = grouped_host[ordered_cols + remaining_cols]
        print("🔄 Columns reordered successfully.")

        # === Save final output ===
        grouped_host.to_excel(OUTPUT_FILE, index=False)
        print(f"💾 Processed file with CVEs saved as: {OUTPUT_FILE}")

    except Exception:
        print("❌ ERROR: An unexpected error occurred.")
        print("-" * 70)
        traceback.print_exc()
        print("-" * 70)
        sys.exit(1)

    print("=" * 70)
    print("🎉 Nessus processing + CVE extraction completed successfully!")

if __name__ == "__main__":
    main()