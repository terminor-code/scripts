import pandas as pd
import os
import sys
import traceback

# === CONFIGURATION ===
INPUT_FILE = "cleaned_Trust_final_v1.0.xlsx"  # Input Excel file (from previous script)
OUTPUT_FILE = "sorted_cleaned_Trust_final_v1.0.xlsx"    # Output Excel file
RISK_PRIORITY = ['Info', 'Low', 'Medium', 'High', 'Critical']  # Hierarchy

def risk_rank(risk):
    """Return index for risk priority (higher is worse)."""
    try:
        return RISK_PRIORITY.index(str(risk).title())
    except ValueError:
        return -1  # unrecognized risk

def main():
    print("🔍 Sorting Nessus Excel and adding serial numbers...")
    print("=" * 60)

    if not os.path.exists(INPUT_FILE):
        print(f"❌ ERROR: Input file '{INPUT_FILE}' not found in directory: {os.getcwd()}")
        sys.exit(1)

    try:
        df = pd.read_excel(INPUT_FILE)
        print(f"📖 Loaded {len(df)} rows and {len(df.columns)} columns.")

        if 'Risk' not in df.columns:
            print("❌ ERROR: 'Risk' column not found in Excel file.")
            sys.exit(1)

        # Sort by Risk hierarchy
        df['Risk_rank'] = df['Risk'].apply(risk_rank)
        df = df.sort_values(by='Risk_rank', ascending=False).drop(columns='Risk_rank')
        print("✅ Sorted rows by Risk hierarchy (Critical > High > Medium > Low > Info).")

        # Add serial numbers
        df.insert(0, 'S.No', range(1, len(df) + 1))
        print("✅ Added Serial Number column at the front.")

        # Save output
        df.to_excel(OUTPUT_FILE, index=False)
        print(f"💾 Output file saved as: {OUTPUT_FILE}")

    except Exception:
        print("❌ ERROR: An unexpected error occurred.")
        print("-" * 60)
        traceback.print_exc()
        print("-" * 60)
        sys.exit(1)

    print("=" * 60)
    print("🎉 Sorting and serial number addition completed successfully.")

if __name__ == "__main__":
    main()